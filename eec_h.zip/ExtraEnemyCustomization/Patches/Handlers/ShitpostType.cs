﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EEC.Patches.Handlers
{
    [Flags]
    public enum ShitpostType
    {
        ForceOff = -1,
        Enable = 0,

        Dinnerbone = 1
    }
}
