﻿namespace EEC.CustomAbilities.EMP
{
    public enum EMPState
    {
        On,
        FlickerOff,
        Off,
        FlickerOn,
    }
}