﻿using Enemies;
using GameData;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace EEC.EnemyCustomizations.Models
{
    public sealed class ShadowCustom : EnemyCustomBase, IEnemySpawnedEvent, IEnemyPrefabBuiltEvent
    {
        public bool IncludeEggSack { get; set; } = false;
        public bool RequireTagForDetection { get; set; } = true;
        public bool FullyInvisible { get; set; } = false;

        public override string GetProcessName()
        {
            return "Shadow";
        }

        public void OnPrefabBuilt(EnemyAgent agent, EnemyDataBlock enemyData)
        {
            agent.RequireTagForDetection = RequireTagForDetection;

            var comps = agent.GetComponentsInChildren<Renderer>(true);
            foreach (var comp in comps)
            {
                if (!IncludeEggSack && comp.gameObject.name.InvariantContains("Egg"))
                {
                    if (Logger.VerboseLogAllowed)
                        LogVerbose(" - Ignored EggSack Object!");
                    comp.shadowCastingMode = ShadowCastingMode.On;
                    comp.enabled = true;
                    continue;
                }

                var skinmeshrenderer = comp.TryCast<SkinnedMeshRenderer>();
                if (skinmeshrenderer != null)
                {
                    skinmeshrenderer.updateWhenOffscreen = true;
                }

                if (FullyInvisible)
                {
                    Object.Destroy(comp);
                }
                else
                {
                    comp.castShadows = true;
                    comp.shadowCastingMode = ShadowCastingMode.ShadowsOnly;
                    comp.gameObject.AddComponent<ShadowEnemyRenderer>(); //Love you mccad00 from gtfo unofficial modding
                }
            }
        }

        public void OnSpawned(EnemyAgent agent)
        {
            agent.MovingCuller.m_disableAnimatorCullingWhenRenderingShadow = true;
            agent.MovingCuller.Culler.hasShadowsEnabled = true;
            agent.SetAnimatorCullingEnabled(false);
        }
    }
}