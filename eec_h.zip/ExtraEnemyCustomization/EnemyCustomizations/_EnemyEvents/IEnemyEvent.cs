﻿namespace EEC.EnemyCustomizations
{
    public interface IEnemyEvent
    {
        EnemyCustomBase Base { get; }
    }
}